<?php
	$CI = get_instance();
	$CI->load->database();
	$CI->load->dbforge();

  // creating online_exam table
  $online_exam_fields = array(
    'online_exam_id' => array(
            'type' => 'INT',
            'primary' => TRUE,
            'auto_increment' => TRUE,
            'constraint' => '11'
    ),
    'code' => array(
            'type' => 'VARCHAR',
			'constraint' => 255,
            'null'  => TRUE,
						'collation' => 'utf8_unicode_ci'
    ),
    'title' => array(
			'type' => 'TEXT',
			'null'  => TRUE,
			'collation' => 'utf8_unicode_ci'
    ),
    'class_id' => array(
            'type' => 'INT',
			'constraint' => '11',
            'null' => TRUE
    ),
    'section_id' => array(
			'type' => 'INT',
			'constraint' => '11',
			'null' => TRUE
    ),
    'subject_id' => array(
			'type' => 'INT',
			'constraint' => '11',
			'null' => TRUE
    ),
    'exam_date' => array(
			'type' => 'INT',
			'constraint' => '11',
			'null' => TRUE
    ),
	'time_start' => array(
            'type' => 'VARCHAR',
			'constraint' => 255,
            'null'  => TRUE,
						'collation' => 'utf8_unicode_ci'
    ),
	'time_end' => array(
            'type' => 'VARCHAR',
			'constraint' => 255,
            'null'  => TRUE,
						'collation' => 'utf8_unicode_ci'
    ),
	'duration' => array(
			'type' => 'TEXT',
			'null'  => TRUE,
			'collation' => 'utf8_unicode_ci'
    ),
	'minimum_percentage' => array(
			'type' => 'TEXT',
			'null'  => TRUE,
			'collation' => 'utf8_unicode_ci'
    ),
	'instruction' => array(
			'type' => 'LONGTEXT',
			'null'  => TRUE,
			'collation' => 'utf8_unicode_ci'
    ),
	'status' => array(
			'type' => 'VARCHAR',
			'constraint' => 255,
			'null'  => TRUE,
			'default' => 'pending',
			'collation' => 'utf8_unicode_ci'
    ),
	'running_year' => array(
			'type' => 'VARCHAR',
			'constraint' => 255,
			'null'  => TRUE,
			'collation' => 'utf8_unicode_ci'
    ),
  );

$CI->dbforge->add_key('online_exam_id', TRUE); // defining online_exam_id as primary key
$CI->dbforge->add_field($online_exam_fields);
$CI->dbforge->create_table('online_exam'); // table has to be added after adding the columns


// creating online_exam_result table
$online_exam_result_fields = array(
  'online_exam_result_id' => array(
          'type' => 'INT',
          'primary' => TRUE,
          'auto_increment' => TRUE,
          'constraint' => '11'
  ),
  'online_exam_id' => array(
          'type' => 'INT',
		  'constraint' => '11',
          'null'  => TRUE
  ),
  'student_id' => array(
          'type' => 'INT',
		  'constraint' => '11',
          'null'  => TRUE
  ),
  'answer_script' => array(
          'type' => 'LONGTEXT',
          'null'  => TRUE
  ),
  'obtained_mark' => array(
          'type' => 'TEXT',
          'null' => TRUE
  ),
  'status' => array(
          'type' => 'TEXT',
          'null' => TRUE
  ),
  'exam_started_timestamp' => array(
          'type' => 'LONGTEXT',
          'null' => TRUE
  ),
  'result' => array(
          'type' => 'TEXT',
          'null' => TRUE
  ),
);

$CI->dbforge->add_key('online_exam_result_id', TRUE); // defining online_exam_result_id as primary key
$CI->dbforge->add_field($online_exam_result_fields);
$CI->dbforge->create_table('online_exam_result'); // table has to be added after adding the columns



// creating question_bank table
$question_bank_fields = array(
  'question_bank_id' => array(
          'type' => 'INT',
          'primary' => TRUE,
          'auto_increment' => TRUE,
          'constraint' => '11'
  ),
  'online_exam_id' => array(
          'type' => 'INT',
		  'constraint' => '11',
          'null'  => TRUE
  ),
  'question_title' => array(
          'type' => 'LONGTEXT',
          'null'  => TRUE
  ),
  'type' => array(
          'type' => 'VARCHAR',
		  'constraint' => '255',
          'null' => TRUE
  ),
  'number_of_options' => array(
          'type' => 'INT',
		  'constraint' => '11',
          'null' => TRUE
  ),
  'options' => array(
          'type' => 'LONGTEXT',
          'null' => TRUE
  ),
  'correct_answers' => array(
          'type' => 'LONGTEXT',
          'null' => TRUE
  ),
  'mark' => array(
          'type' => 'VARCHAR',
		  'constraint' => '255',
          'null' => TRUE
  ),
);

$CI->dbforge->add_key('question_bank_id', TRUE); // defining question_bank_id as primary key
$CI->dbforge->add_field($question_bank_fields);
$CI->dbforge->create_table('question_bank'); // table has to be added after adding the columns

//insert disable_frontend row
$disable_frontend_updater = array(
	'type' => 'disable_frontend',
	'description' => 0
);
$CI->db->insert('settings',$disable_frontend_updater);
?>
